from __future__ import print_function
from __future__ import division

from dbn.tensorflow import SupervisedDBNClassification
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import accuracy_score
import numpy as np
import os
from tensorflow.python.keras import datasets
from copy import deepcopy
import random

(X_train,y_train), (X_test, y_test) = datasets.cifar10.load_data()

pretrain_num = 10000
train_num = 10000
valid_num = 2000
X_train=X_train/255
X_test=X_test/255
X_train = X_train.reshape(50000, 32*32*3)
X_test = X_test.reshape(10000, 32*32*3)
y_train = y_train.reshape(50000, )
y_test = y_test.reshape(10000, )


dbn = SupervisedDBNClassification(
    hidden_layers_structure=[512,256,128],
    #learning_rate_rbm=0.002,
    learning_rate_rbm=0.01,
    learning_rate=0.02,
    #n_epochs_rbm=200,
    n_epochs_rbm=20,
    n_iter_backprop=5000,
    batch_size=100,
    activation_function='sigmoid',
    dropout_p=0.2
)
valid_x = np.array(X_train[102+train_num:102+train_num+valid_num])
valid_y = np.array(y_train[102+train_num:102+train_num+valid_num])

unlabeled_rmb_pretrain_data = X_train[15000:15000+pretrain_num]
dbn.pretrain(unlabeled_rmb_pretrain_data)


dbn.fit(X_train[102:102+train_num], y_train[102:102+train_num], valid_x, valid_y, X_test, y_test)

attack_size = 1
num_attack = 10000
attack_index = 0

testX_attacked = deepcopy(X_test[attack_index:attack_index+num_attack])
testY_attacked = y_test[attack_index:attack_index+num_attack]
#print('here123', testX_attacked.shape)
#print(testY_attacked.shape)
initial_predictions = dbn.predict(testX_attacked)
initial_accuracy = accuracy_score(testY_attacked, list(initial_predictions))
#print('initial Accuracy: {0}'.format(initial_accuracy))

testX_attacked = testX_attacked.reshape(num_attack,32,32,3)
this_arr = []
output_arr = []
total_count = 0
success_count = 0

for i in range(num_attack):
    #if(i%50==0):
    #    print(i)
    this_arr = []
    chechacc_X = deepcopy(testX_attacked[i:i+1])
    chechacc_Y = np.empty(1)
    chechacc_Y[:] = testY_attacked[i]
    chechacc_X = chechacc_X.reshape(1,32*32*3)
    #print('here123', chechacc_X.shape)
    #print(chechacc_Y.shape)
    check_predictions = dbn.predict(chechacc_X)
    check_accuracy = accuracy_score(chechacc_Y, list(check_predictions))
    #print(check_accuracy==1.0)

    #print('Accuracy: {0}'.format(check_accuracy))
    if(check_accuracy == 1.0):
        total_count = total_count + 1
        this_X = deepcopy(testX_attacked[i:i+1])
        this_X = this_X.reshape(1,32,32,3)
        for index1 in range(32):
            for index2 in range(32):
                r_noise = random.uniform(-0.1, 0.1)
                g_noise = random.uniform(-0.1, 0.1)
                b_noise = random.uniform(-0.1, 0.1)
                this_X[0][index1][index2][0] = this_X[0][index1][index2][0] + r_noise
                this_X[0][index1][index2][1] = this_X[0][index1][index2][1] + g_noise
                this_X[0][index1][index2][2] = this_X[0][index1][index2][2] + b_noise
                
                this_X[0][index1][index2][0] = max(0, this_X[0][index1][index2][0])
                this_X[0][index1][index2][0] = min(1, this_X[0][index1][index2][0])
                this_X[0][index1][index2][1] = max(0, this_X[0][index1][index2][1])
                this_X[0][index1][index2][1] = min(1, this_X[0][index1][index2][1])
                this_X[0][index1][index2][2] = max(0, this_X[0][index1][index2][2])
                this_X[0][index1][index2][2] = min(1, this_X[0][index1][index2][2])
        
        attack_arr = np.array(this_X)
        attack_arr = attack_arr.reshape(1, 32*32*3)
        #print('here321', attack_arr.shape)

        attack_predictions = dbn.predict(attack_arr)
        
        attack_accuracy = accuracy_score(chechacc_Y, list(attack_predictions))
        #print(attack_accuracy)

        #print(attack_accuracy==1.0)
        
        if(attack_accuracy != 1.0):
            success_count = success_count + 1
            output_arr.append(1000001)
        else:
            output_arr.append(1)
    else:
        output_arr.append(0)

print(total_count)
print(success_count)

print(len(output_arr))
output_ndarr = np.array(output_arr)
#np.savetxt('C:/Users/13766/Desktop/Honor_code_Tao_Yang_2020/CIFAR-10 random noise attack/DBN code/DBN_data.csv', output_ndarr, delimiter=",")
