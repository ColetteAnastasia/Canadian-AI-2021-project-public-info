"""
Deep Belief Networks using Deep Belief Network
and TensorFlow. The DBN folder contains the deep-belief-network package
originally downloaded from https://github.com/albertbup/deep-belief-network
on March 29, 2017, and modified slightly to support python3. The
DBN folder is covered under the MIT license.
"""
from __future__ import print_function
from __future__ import division

from dbn.tensorflow import SupervisedDBNClassification
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import accuracy_score
import numpy as np
import os
from tensorflow.python.keras import datasets
import csv

(X_train,y_train), (X_test, y_test) = datasets.cifar10.load_data()

train_sample = 7000
X_train=X_train/255
X_test=X_test/255
X_train = X_train.reshape(50000, 32*32*3)
X_test = X_test.reshape(10000, 32*32*3)
y_train = y_train.reshape(50000, )
y_test = y_test.reshape(10000, )


dbn = SupervisedDBNClassification(
    hidden_layers_structure=[512,256],
    learning_rate_rbm=0.01,
    learning_rate=0.1,
    n_epochs_rbm=20,
    n_iter_backprop=400,
    batch_size=100,
    activation_function='relu',
    dropout_p=0.2
)


#dbn.fit(X_train[:train_sample], y_train[:train_sample])

dbn.fit(X_train[1000:8000], X_train[102:202], y_train[102:202])

predictions = dbn.predict(X_test)
accuracy = accuracy_score(y_test, list(predictions))
print('Normal Accuracy: {0}'.format(accuracy))



#===================================================================== one pixel attack
csvFile = open("C:/Users/13766/Desktop/current progress 08 31/DBN code/One-pixel-attack/data.csv", "r")
reader = csv.reader(csvFile)
list_data = []
outerflag = True
for item in reader:
    innerflag = True
    if outerflag:
        outerflag = False
    else:
        for value in item:
            if innerflag:
                innerflag = False
                continue
            else:
                list_data.append(float(value))
csvFile.close()



csvFile = open("C:/Users/13766/Desktop/current progress 08 31/DBN code/One-pixel-attack/label.csv", "r")
reader = csv.reader(csvFile)
list_label = []
outerflag = True
index = 0
for item in reader:
    innerflag = True
    if outerflag:
        outerflag = False
    else:
        index = 0
        for value in item:
            if innerflag:
                innerflag = False
                continue
            else:
                if (value=='1'):
                    list_label.append(int(index))
                    index = 0
                    break
                else:
                    index = index + 1
csvFile.close()

one_pixel_attack_data = np.array(list_data).reshape(100,32*32*3)
one_pixel_attack_data = one_pixel_attack_data/255
one_pixel_attack_label = np.array(list_label).reshape(100,)


predictions = dbn.predict(one_pixel_attack_data)
accuracy = accuracy_score(one_pixel_attack_label, list(predictions))
print('One-pixel-attack Accuracy: {0}'.format(accuracy))