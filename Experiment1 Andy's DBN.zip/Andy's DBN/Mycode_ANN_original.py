import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data
mnist= input_data.read_data_sets('data/', one_hot=True)

n_hidden_1 = 512
n_hidden_2 = 256
n_hidden_3 = 512
n_input    = 784
n_classes  = 10
x = tf.placeholder("float", [None, n_input])
y = tf.placeholder("float", [None, n_classes])

stddev = 0.1
weights = {
    'w1': tf.Variable(tf.random_normal([n_input, n_hidden_1], stddev=stddev)),
    'w2': tf.Variable(tf.random_normal([n_hidden_1, n_hidden_2], stddev=stddev)),
    'w3': tf.Variable(tf.random_normal([n_hidden_2, n_hidden_3], stddev=stddev)),
    'out': tf.Variable(tf.random_normal([n_hidden_3, n_classes], stddev=stddev))
}
biases = {
    'b1': tf.Variable(tf.random_normal([n_hidden_1])),
    'b2': tf.Variable(tf.random_normal([n_hidden_2])),
    'b3': tf.Variable(tf.random_normal([n_hidden_3])),
    'out': tf.Variable(tf.random_normal([n_classes]))
}

def multilayer_perceptron(_X, _weights, _biases):
    layer_1 = tf.nn.relu(tf.add(tf.matmul(_X, _weights['w1']), _biases['b1']))
    layer_2 = tf.nn.relu(tf.add(tf.matmul(layer_1, _weights['w2']), _biases['b2']))
    layer_3 = tf.nn.relu(tf.add(tf.matmul(layer_2, _weights['w3']), _biases['b3']))
    return (tf.matmul(layer_3, _weights['out']) + _biases['out'])

pred = multilayer_perceptron(x, weights, biases)

loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=y,logits=pred,name="loss"))
optm = tf.train.GradientDescentOptimizer(0.001)
train=optm.minimize(loss)
corr = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
accr = tf.reduce_mean(tf.cast(corr, "float"))

init = tf.global_variables_initializer()
training_epochs = 1500
batch_size = 50
display_step = 1
sess = tf.Session()
sess.run(init)
top_test_acc = 0
patient = 20
train_num = 10000                                     #the only thing i want to change
count = 0
for epoch in range(training_epochs):
    if(count >= patient):
        break
    avg_cost = 0.
    total_batch = int(train_num/batch_size)
    for i in range(total_batch):
        batch_xs, batch_ys = mnist.train.next_batch(batch_size)
        feeds = {x: batch_xs, y: batch_ys}
        sess.run(train, feed_dict=feeds)
        avg_cost += sess.run(loss, feed_dict=feeds)
    avg_cost = avg_cost / total_batch
    if epoch % display_step == 0:
        #print("Epoch: %03d/%03d cost: %.9f" % (epoch, training_epochs, avg_cost))
        feeds = {x: batch_xs, y: batch_ys}
        train_acc = sess.run(accr, feed_dict=feeds)
        #print("TRAIN ACCURACY: %.3f" % (train_acc))
        feedstest = {x: mnist.test.images, y: mnist.test.labels}
        test_acc = sess.run(accr, feed_dict=feedstest)
        if(top_test_acc < test_acc):
            top_test_acc = test_acc
            count = 0
        else:
            count = count + 1
        #print("TEST ACCURACY: %.3f" % (test_acc))
        #print("Epoch: %03d/%03d cost: %.9f \t test_accuracy: %.3f \t patient_count: %d" % (epoch, training_epochs, avg_cost, test_acc, count))
        
print("Top test accuracy: %.4f" % (top_test_acc))