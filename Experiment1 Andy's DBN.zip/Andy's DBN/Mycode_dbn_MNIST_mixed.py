"""
Deep Belief Networks using Deep Belief Network
and TensorFlow. The DBN folder contains the deep-belief-network package
originally downloaded from https://github.com/albertbup/deep-belief-network
on March 29, 2017, and modified slightly to support python3. The
DBN folder is covered under the MIT license.
"""
from __future__ import print_function
from __future__ import division

from dbn.tensorflow import SupervisedDBNClassification
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import accuracy_score
from tensorflow.contrib.learn.python.learn.datasets.mnist import read_data_sets
import numpy as np
import random

#from sklearn.externals import joblib


dbn = SupervisedDBNClassification(
    hidden_layers_structure=[512,256,512],
    learning_rate_rbm=0.008,
    learning_rate=0.01,
    n_epochs_rbm=19,
    n_iter_backprop=1500,                                          # make n_iter_backprop big enough so dbn get well trained
    batch_size=100,
    activation_function='relu',
    dropout_p=0.17
)

#total_run = 20
pretrain_size = 10000
total = 500                                                       # "total" is the only thing I want to change
validation_size = int(total / 5)
train_size = validation_size * 4
test_size = 10000
thisrange = 25000 - train_size - 1                                 # to make training samples random each time I run the code
mnist = read_data_sets('MNIST_data/', one_hot=False)

pretrain_flag = True
#pretrain_flag = False

#else:
#    dbn.load('C:/Users/13766/Desktop/current progress 07 26/DBN code/Andy\'s DBN/my_dbn_model.pkl')
#    print(dbn)
#    print(dbn.unsupervised_dbn.rbm_layers)

#for index in range(total_run):



shuffle_index  = [x for x in range(28*28)]                         # prepare to mix the pixels
random.shuffle(shuffle_index)

randnum = random.randint(0,thisrange)
#print(randnum)

for i in range(50000):                                             # mix the pixel from line 47 to line 55
    this_x_train = mnist.train.images[i]
    for j in range(len(mnist.train.images[i])):
        mnist.train.images[i][j]=this_x_train[shuffle_index[j]]

for i in range(10000):
    this_x_test = mnist.test.images[i]
    for j in range(len(mnist.test.images[i])):
        mnist.test.images[i][j]=this_x_test[shuffle_index[j]]
        
unlabeled_rmb_pretrain_data = np.array(mnist.train.images[(49999 - pretrain_size):49999])
if pretrain_flag:
    dbn.pretrain(unlabeled_rmb_pretrain_data)

test_image = mnist.train.images[randnum:train_size+validation_size+randnum+5000]       # give 5000 more samples since we need equally 0 to 9s
test_label = mnist.train.labels[randnum:train_size+validation_size+randnum+5000]
training_image = []
training_label = []
magic_num = (train_size + validation_size)/10                                          # make sure training data has equal numbers of samples for 0 to 9, line 62 to 128
count_0 = 0
count_1 = 0
count_2 = 0
count_3 = 0
count_4 = 0
count_5 = 0
count_6 = 0
count_7 = 0
count_8 = 0
count_9 = 0
total = 0
for index, val in enumerate(test_label):
    if val==0 and count_0 < magic_num:
        count_0 = count_0 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==1 and count_1 < magic_num:
        count_1 = count_1 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==2 and count_2 < magic_num:
        count_2 = count_2 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==3 and count_3 < magic_num:
        count_3 = count_3 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==4 and count_4 < magic_num:
        count_4 = count_4 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==5 and count_5 < magic_num:
        count_5 = count_5 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==6 and count_6 < magic_num:
        count_6 = count_6 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==7 and count_7 < magic_num:
        count_7 = count_7 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==8 and count_8 < magic_num:
        count_8 = count_8 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    elif val==9 and count_9 < magic_num:
        count_9 = count_9 + 1
        total = total + 1
        training_image.append(test_image[index])
        training_label.append(val)
    if total == (train_size + validation_size):
        print()
        break

this_train_arr = training_image[0:train_size]
this_train_label = training_label[0:train_size]
validation_x = training_image[train_size:train_size + validation_size + 1]
validation_y = training_label[train_size:train_size + validation_size + 1]



    #validation_x = mnist.train.images[(49999 - validation_size):49999]                     # independent validation samples from #40000 to # 50000, not using them any more
    #validation_y = mnist.train.labels[(49999 - validation_size):49999]

training_image = np.array(this_train_arr)
training_label = np.array(this_train_label)


    #print(training_label)
    #print(validation_y)





dbn.fit(training_image, training_label, validation_x, validation_y, mnist.test.images, mnist.test.labels, pre_train = pretrain_flag)    #pass everything to "./Andy's DBN/dbn/tensorflow/models.py"



#joblib.dump(dbn, 'my_dbn_model.pkl') 
#gugugu = joblib.load('my_dbn_model.pkl') 


#print('123123123')

#predictions = dbn.predict(mnist.test.images)
#accuracy = accuracy_score(mnist.test.labels, list(predictions))

#print('Accuracy: {0}'.format(accuracy))


#SupervisedDBNClassification(batch_size=100, dropout_p=0.17,
#                            idx_to_label_map=None, l2_regularization=1.0,
#                            label_to_idx_map=None, learning_rate=0.1,
#                            n_iter_backprop=1500, verbose=True)

#SupervisedDBNClassification(batch_size=100, dropout_p=0.17,
#                            idx_to_label_map={0: 0, 1: 8, 2: 1, 3: 4, 4: 2,
#                                              5: 5, 6: 3, 7: 7, 8: 6, 9: 9},
#                            l2_regularization=1.0,
#                            label_to_idx_map={0: 0, 1: 2, 2: 4, 3: 6, 4: 3,
#                                              5: 5, 6: 8, 7: 7, 8: 1, 9: 9},
#                            learning_rate=0.1, n_iter_backprop=1500,
#                            verbose=True)
